/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labeledstatment;

/**
 *
 * @author Ahmed said
 */
public class Labeledstatment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //unlabelled break statement
        for (int x = 1; x < 11; x++) {
            System.out.println(x);
            if (x == 8) {
                System.out.println("Found 8");
                break;
            }
        }

        //labelled break statement
        outerbreak:
        for (int x = 1; x < 11; x++) {
            System.out.println(x);

            for (int z = 1; z < 6; z++) {
                System.out.println(z + "inner loop");
                if (z == 4) {
                    System.out.println("Found 4");
                    break outerbreak;
                }
            }

        }
    }

}
        
        
    
    

